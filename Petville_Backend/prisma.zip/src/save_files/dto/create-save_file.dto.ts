export class CreateSaveFileDto {
    user_id: number;
    petName: string;
    petType: string;
    petEnergy: number ;
    petHunger: number;
    petMood: number;
    petHealth: number;
    hoursPlayer: number;
    goldEarned: number;
    currentGold: number;
}
