export class Leaderboard {}
