export class CreateLeaderboardDto {
    user_id: number;
    score: number;
}
