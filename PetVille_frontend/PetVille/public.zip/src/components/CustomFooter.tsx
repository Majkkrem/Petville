

function CustomFooter(){
    return(
        <footer className="bg-dark py-3">
          <p className="text-center" id="footer-text">© 2025 PetVille</p>
        </footer>
    )
}

export default CustomFooter


// teszt@teszt.hu
// Teszt
// TesztAjelszo11